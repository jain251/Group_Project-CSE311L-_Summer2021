<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(asset('assets/admin/css/bootstrap-fileinput.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col-md-12">

            <div class="portlet box blue">
                <div class="portlet-title">
                    <div class="caption">
                        <i class="fa fa-photo"></i> <strong><?php echo e($page_title); ?></strong>
                    </div>
                    <div class="tools">
                        <a href="javascript:;" class="collapse"> </a>
                    </div>
                </div>
                <div class="portlet-body">

                    <div class="row">
                        <div class="col-md-4">
                            <div class="portlet box blue">
                                <div class="portlet-title">
                                    <div class="caption uppercase bold"><i class="fa fa-edit"></i> CHANGE Breadcrumb</div>
                                </div>
                                <div class="portlet-body">

                                    <?php echo Form::open(['files'=>true]); ?>


                                    <div class="row">

                                        <div class="form-group">
                                            <label class="col-md-12"><strong style="text-transform: uppercase;">Change Breadcrumb</strong></label>
                                            <div class="col-sm-12">
                                                <div class="fileinput fileinput-new" data-provides="fileinput">
                                                    <div class="input-group input-large">
                                                        <div class="form-control uneditable-input input-fixed input-medium" data-trigger="fileinput">
                                                            <i class="fa fa-file fileinput-exists"></i>&nbsp;
                                                            <span class="fileinput-filename"> </span>
                                                        </div>
                                                        <span class="input-group-addon btn default btn-file">
                                                                    <span class="fileinput-new bold"> Change Breadcrumb </span>
                                                                    <span class="fileinput-exists bold"> Change </span>
                                                                    <input type="file" name="breadcrumb"> </span>
                                                        <a href="javascript:;" class="input-group-addon btn red fileinput-exists" data-dismiss="fileinput"> Remove </a>
                                                    </div>
                                                    <code>Breadcrumb Mimes Type : png,jpeg,jpg | Resize 1280X560</code>
                                                </div>
                                            </div>
                                            <br>
                                            <br>
                                        </div>

                                        <br>
                                        <br>
                                        <br>
                                        <div class="form-group">
                                            <div class="col-sm-12"> <button type="submit" class="btn btn-primary bold btn-block"><i class="fa fa-send"></i> UPDATE</button></div>
                                        </div>
                                    </div>
                                    <?php echo Form::close(); ?>

                                </div>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="portlet box blue">
                                <div class="portlet-title">
                                    <div class="caption uppercase bold"><i class="fa fa-photo"></i> Current Image</div>
                                </div>
                                <div class="portlet-body">
                                    <img class="img-responsive" src="<?php echo e(asset('assets/images')); ?>/<?php echo e($basic->breadcrumb); ?>" alt="logo">
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('assets/admin/js/bootstrap-fileinput.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>