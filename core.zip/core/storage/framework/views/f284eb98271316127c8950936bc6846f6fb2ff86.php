<?php $__env->startSection('style'); ?>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-primary panel-shadow" data-collapsed="0"><!-- to apply shadow add class "panel-shadow" -->

                <!-- panel head -->
                <div class="panel-heading">
                    <div class="panel-title"><i class="fa fa-send"></i> <strong><?php echo e($page_title); ?></strong></div>
                </div>

                <!-- panel body -->
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="col-sm-12 text-center">
                                <div class="panel panel-primary panel-pricing">
                                    <div class="panel-heading">
                                        <h3 style="font-size: 28px;"><b><?php echo e($method->name); ?></b></h3>
                                    </div>
                                    <div style="font-size: 18px;padding: 18px;" class="panel-body text-center">
                                        <img class="" style="width: 35%;border-radius: 5px" src="<?php echo e(asset('assets/images')); ?>/<?php echo e($method->image); ?>" alt="">
                                    </div>
                                    <ul style='font-size: 15px;' class="list-group text-center bold">
                                        <li class="list-group-item">Limit - ( <?php echo $method->withdraw_min; ?> to <?php echo e($method->withdraw_max); ?> ) <?php echo e($basic->currency); ?> </li>
                                        <li class="list-group-item"> Fix Charge - <?php echo e($method->fix); ?> <?php echo e($basic->currency); ?></li>
                                        <li class="list-group-item"> Percentage - <?php echo e($method->percent); ?><i class="fa fa-percent"></i></li>
                                        <li class="list-group-item">Duration - <?php echo $method->duration; ?> Days </li>
                                    </ul>
                                    <div class="panel-footer" style="overflow: hidden">
                                        <div class="col-sm-12">
                                            <a href="<?php echo e(route('withdraw-request')); ?>" class="btn bold uppercase btn-info btn-block btn-icon icon-left"><i class="fa fa-arrow-left"></i> Another Method</a>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8 col-sm-12">
                            <div class="panel panel-primary panel-shadow" data-collapsed="0"><!-- to apply shadow add class "panel-shadow" -->

                                <!-- panel head -->
                                <div class="panel-heading">
                                    <div class="panel-title"><i class="fa fa-money"></i> <strong><?php echo e($page_title); ?></strong></div>
                                </div>
                                <!-- panel body -->
                                <div class="panel-body">
                                    <div class="text-center">
                                        <h3 class="bold uppercase">Current Balance : <strong><?php echo e($balance->balance); ?> - <?php echo e($basic->currency); ?></strong></h3>
                                    </div>
                                    <hr>
                                    <div class="row">
                                        <div class="form-group">
                                            <label style="margin-top: 5px;font-size: 14px;" class="col-sm-4 col-sm-offset-1 bold uppercase text-right control-label">Request Amount : </label>

                                            <div class="col-sm-3">
                                                <div class="input-group">
                                                    <input type="text" value="<?php echo e($withdraw->amount); ?>" readonly name="amount" id="amount" class="form-control bold" placeholder="Enter Deposit Amount" required>
                                                    <span class="input-group-addon red">&nbsp;<strong> <?php echo e($basic->currency); ?> </strong></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <br>
                                    <div class="row">
                                        <div class="form-group">
                                            <label style="margin-top: 5px;font-size: 14px;" class="col-sm-4 col-sm-offset-1 text-right bold uppercase control-label">Withdrawal Charge : </label>

                                            <div class="col-sm-3">
                                                <div class="input-group">
                                                    <input type="text" value="<?php echo e(round($withdraw->charge,$basic->deci )); ?>" readonly name="charge" id="charge" class="form-control bold" placeholder="Enter Deposit Amount" required>
                                                    <span class="input-group-addon red">&nbsp;<strong> <?php echo e($basic->currency); ?> </strong></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="row">
                                        <div class="form-group">
                                            <label style="margin-top: 5px;font-size: 14px;" class="col-sm-4 col-sm-offset-1 bold uppercase text-right control-label">Total Amount : </label>

                                            <div class="col-sm-3">
                                                <div class="input-group">
                                                    <input type="text" value="<?php echo e($withdraw->net_amount); ?>" readonly name="charge" id="charge" class="form-control bold" placeholder="Enter Deposit Amount" required>
                                                    <span class="input-group-addon red">&nbsp;<strong> <?php echo e($basic->currency); ?> </strong></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <br>
                                    <div class="row">
                                        <div class="form-group">
                                            <label style="margin-top: 5px;font-size: 14px;" class="col-sm-4 col-sm-offset-1 bold uppercase text-right control-label">Available Balance : </label>

                                            <div class="col-sm-3">
                                                <div class="input-group">
                                                    <input type="text" value="<?php echo e($balance->balance - $withdraw->net_amount); ?>" readonly name="charge" id="charge" class="form-control bold" placeholder="Enter Deposit Amount" required>
                                                    <span class="input-group-addon red">&nbsp;<strong> <?php echo e($basic->currency); ?> </strong></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="col-md-12">
                        <div class="panel panel-primary panel-shadow" data-collapsed="0"><!-- to apply shadow add class "panel-shadow" -->

                            <!-- panel head -->
                            <div class="panel-heading">
                                <div class="panel-title"><i class="fa fa-send"></i> <strong>Payment Send Details</strong></div>
                            </div>
                            <!-- panel body -->
                            <div class="panel-body">
                                <div class="col-md-12">

                                        <?php echo Form::open(['route'=>'withdraw-submit']); ?>

                                        <input type="hidden" name="withdraw_id" value="<?php echo e($withdraw->id); ?>">
                                        <div class="row">
                                            <div class="form-group">
                                                <label style="margin-top: 5px;font-size: 14px;" class="col-sm-2 bold uppercase text-right  control-label">Sending Details : </label>

                                                <div class="col-sm-8">

                                                <textarea name="send_details" id="" rows="4"
                                                          class="form-control bold input-lg" placeholder="Sending Details" required></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <br>
                                        <div class="row">
                                            <div class="form-group">
                                                <label style="margin-top: 5px;font-size: 14px;" class="col-sm-2 bold uppercase text-right control-label">Message  : </label>

                                                <div class="col-sm-8">

                                                <textarea name="message" id="" rows="3"
                                                          class="form-control bold input-lg" placeholder="Message ( If Any )"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <br>
                                        <div class="row">
                                            <div class="form-group">

                                                <div class="col-sm-8 col-sm-offset-2">
                                                    <button class="btn btn-primary btn-icon bold uppercase icon-left btn-block"><i class="fa fa-send"></i> Submit Withdraw</button>
                                                </div>
                                            </div>
                                        </div>
                                        <?php echo Form::close(); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div><!---ROW-->



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>