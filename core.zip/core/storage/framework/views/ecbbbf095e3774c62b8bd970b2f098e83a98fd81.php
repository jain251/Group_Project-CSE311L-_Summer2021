
<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col-md-12">


            <div class="portlet light bordered">
                <div class="portlet-title">
                    <div class="caption font-dark">
                    </div>
                    <div class="tools"> </div>
                </div>
                <div class="portlet-body">
                    <table class="table table-striped table-bordered table-hover" id="samle_1">

                        <thead>
                        <tr>
                            <th>ID#</th>
                            <th>Repeat Date Time</th>
                            <th>Transaction ID</th>
                            <th>User Name</th>
                            <th>User Email</th>
                            <th>Investment Plan</th>
                            <th>Investment Amount</th>
                            <th>Repeat Amount</th>
                            <th>Repeat Percentage</th>
                        </tr>
                        </thead>

                        <tbody>
                        <?php $i=0;?>
                        <?php $__currentLoopData = $log; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $i++;?>
                            <tr>
                                <td><?php echo e($i); ?></td>
                                <td><?php echo e(date('d-F-Y h:i A',strtotime($p->created_at))); ?></td>
                                <td><?php echo e($p->trx_id); ?></td>
                                <td><?php echo e($p->user->username); ?></td>
                                <td><?php echo e($p->user->email); ?></td>
                                <td><?php echo e($p->invest->plan->name); ?></td>
                                <td><?php echo e($p->invest->amount); ?> - <?php echo e($basic->currency); ?></td>
                                <td><?php echo e($p->amount); ?> - <?php echo e($basic->currency); ?></td>
                                <td><?php echo e($p->invest->plan->percent); ?> %</td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="text-center">
                        <?php echo $log->links(); ?>

                    </div>
                </div>
            </div>

        </div>
    </div><!-- ROW-->



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>