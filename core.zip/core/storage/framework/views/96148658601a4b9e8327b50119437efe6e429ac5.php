<?php $__env->startSection('style'); ?>
    <script type="text/javascript" src="http://js.nicedit.com/nicEdit-latest.js"></script>

    <script type="text/javascript">
        bkLib.onDomLoaded(function() { new nicEditor({fullPanel : true}).panelInstance('area1'); });
    </script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">


            <div class="portlet box blue">
                <div class="portlet-title">
                    <div class="caption font-dark bold uppercase"><strong><i class="fa fa-cloud-download"></i> Deposit Fund preview</strong>
                    </div>
                    <div class="tools"> </div>
                </div>

                <div class="portlet-body">
                    <div class="row">
                        <div class="col-md-4 col-sm-12 text-center">

                                <div class="panel panel-primary">
                                    <div class="panel-heading">
                                        <h3 style="font-size: 28px;"><b>
                                                <?php if($fund->payment_type == 1): ?>
                                                    Paypal
                                                <?php elseif($fund->payment_type == 2): ?>
                                                    Perfect Money
                                                <?php elseif($fund->payment_type == 3): ?>
                                                    BTC - ( BlockChain )
                                                <?php elseif($fund->payment_type == 4): ?>
                                                    Credit Card
                                                <?php else: ?>
                                                    <?php $__currentLoopData = $bank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($b->id == $fund->payment_type): ?>
                                                            <?php echo e($b->name); ?>

                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </b></h3>
                                    </div>
                                    <div style="font-size: 18px;padding: 18px;" class="panel-body text-center">
                                        <?php if($fund->payment_type == 1): ?>
                                            <?php $img = $paypal->image ?>
                                        <?php elseif($fund->payment_type == 2): ?>
                                            <?php $img = $perfect->image ?>
                                        <?php elseif($fund->payment_type == 3): ?>
                                            <?php $img = $btc->image ?>
                                        <?php elseif($fund->payment_type == 4): ?>
                                            <?php $img = $stripe->image ?>
                                        <?php else: ?>
                                            <?php $__currentLoopData = $bank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($b->id == $fund->payment_type): ?>
                                                    <?php $img = $b->image ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        <img width="100%" class="image-responsive" src="<?php echo e(asset('assets/images')); ?>/<?php echo e($img); ?>" alt="">
                                    </div>
                                    <div class="panel-footer">
                                        <a href="<?php echo e(route('deposit-fund')); ?>" class="btn btn-primary btn-block btn-icon icon-left"><i
                                                    class="fa fa-arrow-left"></i> Back to Payment Method Page</a>
                                    </div>
                                </div>
                        </div>
                        <div class="col-md-8 col-sm-12">
                            <div class="panel panel-primary panel-shadow" data-collapsed="0"><!-- to apply shadow add class "panel-shadow" -->

                                <!-- panel head -->
                                <div class="panel-heading">
                                    <div class="panel-title"><i class="fa fa-money"></i> <strong><?php echo e($page_title); ?></strong></div>
                                </div>
                                <!-- panel body -->
                                <div class="panel-body">


                                    <?php if($fund->payment_type == 1 or $fund->payment_type == 2 or $fund->payment_type == 3 or $fund->payment_type == 4): ?>

                                    <div class="row">
                                        <div class="form-group">
                                            <label style="margin-top: 5px;font-size: 14px;" class="col-sm-4 col-sm-offset-1 text-right control-label"><strong>Deposit Amount : </strong></label>

                                            <div class="col-sm-4">
                                                <div class="input-group">
                                                    <input type="text" value="<?php echo e($fund->amount); ?>" readonly name="amount" id="amount" class="form-control bold" placeholder="Enter Deposit Amount" required>
                                                    <span class="input-group-addon red">&nbsp;<strong> <?php echo e($basic->currency); ?> </strong></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <br>
                                    <div class="row">
                                        <div class="form-group">
                                            <label style="margin-top: 5px;font-size: 14px;" class="col-sm-4 col-sm-offset-1 text-right control-label"><strong>Charge : </strong></label>

                                            <div class="col-sm-4">
                                                <div class="input-group">
                                                    <input type="text" value="<?php echo e($fund->charge); ?>" readonly name="charge" id="charge" class="form-control bold" placeholder="Enter Deposit Amount" required>
                                                    <span class="input-group-addon red">&nbsp;<strong> <?php echo e($basic->currency); ?> </strong></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <br>
                                    <div class="row">
                                        <div class="form-group">
                                            <label style="margin-top: 5px;font-size: 14px;" class="col-sm-4 col-sm-offset-1 text-right control-label"><strong>Total Send : </strong></label>

                                            <div class="col-sm-4">
                                                <div class="input-group">
                                                    <input type="text" value="<?php echo e($fund->amount + $fund->charge); ?>" readonly name="" id="" class="form-control bold" placeholder="Enter Deposit Amount" required>
                                                    <span class="input-group-addon red">&nbsp;<strong> <?php echo e($basic->currency); ?> </strong></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                        <br>
                                        <div class="row">
                                            <div class="form-group">
                                                <label style="margin-top: 5px;font-size: 14px;" class="col-sm-4 col-sm-offset-1 text-right control-label"><strong>Conversion Rate : </strong></label>

                                                <div class="col-sm-4">
                                                    <div class="input-group">
                                                        <input type="text" value="1 USD = <?php echo e($fund->payment->rate); ?>" readonly name="charge" id="charge" class="form-control bold" placeholder="Enter Deposit Amount" required>
                                                        <span class="input-group-addon red">&nbsp;<strong> <?php echo e($basic->currency); ?> </strong></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <br>
                                        <div class="row">
                                            <div class="form-group">
                                                <label style="margin-top: 5px;font-size: 14px;" class="col-sm-4 col-sm-offset-1 text-right control-label"><strong>Total Amount : </strong></label>

                                                <div class="col-sm-4">
                                                    <div class="input-group">
                                                        <input type="text" value="<?php echo e(round($fund->net_amount / $fund->payment->rate,3)); ?>" readonly name="charge" id="charge" class="form-control bold" placeholder="Enter Deposit Amount" required>
                                                        <span class="input-group-addon red">&nbsp;<strong> USD </strong></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <br>
                                    <hr>
                                    <?php if($fund->payment_type == 1): ?>
                                        <div class="row">
                                            <form action="https://secure.paypal.com/uk/cgi-bin/webscr" method="post" name="paypal" id="paypal">
                                                <input type="hidden" name="cmd" value="_xclick" />
                                                <input type="hidden" name="business" value="<?php echo e($paypal->val1); ?>" />
                                                <input type="hidden" name="cbt" value="<?php echo e($site_title); ?>" />
                                                <input type="hidden" name="currency_code" value="USD" />
                                                <input type="hidden" name="quantity" value="1" />
                                                <input type="hidden" name="item_name" value="Add Fund to <?php echo e($site_title); ?>" />

                                                <!-- Custom value you want to send and process back in the IPN -->
                                                <input type="hidden" name="custom" value="<?php echo e($fund->custom); ?>" />

                                                <input name="amount" type="hidden" value="<?php echo e($fund->usd); ?>">
                                                <input type="hidden" name="return" value="<?php echo e(route('deposit-fund')); ?>"/>
                                                <input type="hidden" name="cancel_return" value="<?php echo e(route('deposit-fund')); ?>" />
                                                <!-- Where to send the PayPal IPN to. -->
                                                <input type="hidden" name="notify_url" value="<?php echo e(route('paypal-ipn')); ?>" />

                                                <div class="form-group">
                                                    <div class="col-sm-6 col-sm-offset-3">
                                                        <button class="btn btn-primary btn-block btn-icon bold icon-left"><i
                                                                    class="fa fa-send"></i> Add Fund Now</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    <?php elseif($fund->payment_type == 2): ?>
                                        <div class="row">
                                            <form action="https://perfectmoney.is/api/step1.asp" method="POST" id="myform">
                                                <input type="hidden" name="PAYEE_ACCOUNT" value="<?php echo e($perfect->val1); ?>">
                                                <input type="hidden" name="PAYEE_NAME" value="<?php echo e($site_title); ?>">
                                                <input type='hidden' name='PAYMENT_ID' value='<?php echo e($fund->custom); ?>'>
                                                <input type="hidden" name="PAYMENT_AMOUNT"  value="<?php echo e(round(($fund->usd),2)); ?>">
                                                <input type="hidden" name="PAYMENT_UNITS" value="USD">
                                                <input type="hidden" name="STATUS_URL" value="<?php echo e(route('perfect-ipn')); ?>">
                                                <input type="hidden" name="PAYMENT_URL" value="<?php echo e(route('deposit-fund')); ?>">
                                                <input type="hidden" name="PAYMENT_URL_METHOD" value="GET">
                                                <input type="hidden" name="NOPAYMENT_URL" value="<?php echo e(route('deposit-fund')); ?>">
                                                <input type="hidden" name="NOPAYMENT_URL_METHOD" value="GET">
                                                <input type="hidden" name="SUGGESTED_MEMO" value="<?php echo e($site_title); ?>">
                                                <input type="hidden" name="BAGGAGE_FIELDS" value="IDENT"><br>

                                                <div class="form-group">
                                                    <div class="col-sm-6 col-sm-offset-3">
                                                        <button class="btn btn-primary btn-block bold btn-icon icon-left"><i
                                                                    class="fa fa-send"></i>Add Fund Now</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    <?php elseif($fund->payment_type == 3): ?>

                                        <div class="row">
                                            <?php echo Form::open(['route'=>'btc-preview']); ?>

                                            <input type="hidden" name="amount" value="<?php echo e(round(($fund->usd),3)); ?>">
                                            <input type="hidden" name="fund_id" value="<?php echo e($fund->id); ?>">
                                            <input type="hidden" name="custom" value="<?php echo e($fund->custom); ?>">
                                            <div class="form-group">
                                                <div class="col-sm-6 col-sm-offset-3">
                                                    <button class="btn btn-primary btn-block bold btn-icon icon-left"><i
                                                                class="fa fa-send"></i>Add Fund Now</button>
                                                </div>
                                            </div>
                                            <?php echo e(Form::close()); ?>

                                        </div>
                                    <?php elseif($fund->payment_type == 4): ?>
                                        <div class="row">
                                            <?php echo Form::open(['route'=>'stripe-preview']); ?>

                                            <input type="hidden" name="amount" value="<?php echo e(round(($fund->usd),2)); ?>">
                                            <input type="hidden" name="fund_id" value="<?php echo e($fund->id); ?>">
                                            <input type="hidden" name="custom" value="<?php echo e($fund->custom); ?>">
                                            <input type="hidden" name="url" value="<?php echo e(route('deposit-fund')); ?>">
                                            <div class="form-group">
                                                <div class="col-sm-6 col-sm-offset-3">
                                                    <button class="btn btn-primary btn-block bold btn-icon icon-left"><i
                                                                class="fa fa-send"></i>Add Fund Now</button>
                                                </div>
                                            </div>
                                            <?php echo e(Form::close()); ?>

                                        </div>
                                    <?php endif; ?>
                                <?php else: ?>

                                        <div class="row">
                                            <div class="form-group">
                                                <label style="margin-top: 5px;font-size: 14px;" class="col-sm-4 col-sm-offset-1 text-right control-label"><strong>Deposit Amount : </strong></label>

                                                <div class="col-sm-4">
                                                    <div class="input-group">
                                                        <input type="text" value="<?php echo e($fund->amount); ?>" readonly name="amount" id="amount" class="form-control bold" placeholder="Enter Deposit Amount" required>
                                                        <span class="input-group-addon red">&nbsp;<strong> <?php echo e($basic->currency); ?> </strong></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <br>
                                        <div class="row">
                                            <div class="form-group">
                                                <label style="margin-top: 5px;font-size: 14px;" class="col-sm-4 col-sm-offset-1 text-right control-label"><strong>Deposit Charge : </strong></label>

                                                <div class="col-sm-4">
                                                    <div class="input-group">
                                                        <input type="text" value="<?php echo e($fund->charge); ?>" readonly name="charge" id="charge" class="form-control bold" placeholder="Enter Deposit Amount" required>
                                                        <span class="input-group-addon red">&nbsp;<strong> <?php echo e($basic->currency); ?> </strong></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <br>
                                        <div class="row">
                                            <div class="form-group">
                                                <label style="margin-top: 5px;font-size: 14px;" class="col-sm-4 col-sm-offset-1 text-right control-label"><strong>Total Amount : </strong></label>

                                                <div class="col-sm-4">
                                                    <div class="input-group">
                                                        <input type="text" value="<?php echo e($fund->amount + $fund->charge); ?>" readonly name="" id="" class="form-control bold" placeholder="Enter Deposit Amount" required>
                                                        <span class="input-group-addon red">&nbsp;<strong> <?php echo e($basic->currency); ?> </strong></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <br>

                                        <div class="row">
                                            <div class="form-group">
                                                <label style="margin-top: 5px;font-size: 14px;" class="col-sm-4 col-sm-offset-1 text-right control-label"><strong>1 <?php echo e($basic->currency); ?> : </strong></label>

                                                <div class="col-sm-4">
                                                    <div class="input-group">
                                                        <input type="text" value=" <?php echo e($fund->payment->rate); ?>" readonly name="charge" id="charge" class="form-control bold" placeholder="Enter Deposit Amount" required>
                                                        <span class="input-group-addon red">&nbsp;<strong> <?php echo e($fund->payment->currency); ?> </strong></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <br>

                                        <div class="row">
                                            <div class="form-group">
                                                <label style="margin-top: 5px;font-size: 14px;" class="col-sm-4 col-sm-offset-1 text-right control-label"><strong>Total Send : </strong></label>

                                                <div class="col-sm-4">
                                                    <div class="input-group">
                                                        <input type="text" value="<?php echo e($fund->net_amount * $fund->payment->rate); ?>" readonly name="" id="" class="form-control bold" placeholder="Enter Deposit Amount" required>
                                                        <span class="input-group-addon red">&nbsp;<strong> <?php echo e($fund->payment->currency); ?> </strong></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <br>



                                        <hr>

                                        <div class="row">
                                            <div class="form-group">

                                                <div class="col-sm-8 col-md-offset-2 text-center">
                                                    <div class="text-center">
                                                        <h4 class="bold" style="font-size: 24px;border-bottom: 2px dotted ;padding-bottom: 15px;text-transform: uppercase">Sending Details</h4>
                                                    </div>
                                                    <strong style="font-size: 20px;">Send Amount : <?php echo e($fund->net_amount * $fund->payment->rate); ?> <?php echo e($fund->payment->currency); ?></strong><br>
                                                    <?php $__currentLoopData = $bank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($b->id == $fund->payment_type): ?>
                                                            <strong style="font-size: 20px;">
                                                                <?php echo $b->val1; ?>

                                                            </strong>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>
                                        </div>
                                        <hr>

                                        <div class="row">
                                            <?php echo Form::open(['route'=>'manual-deposit-submit','class'=>'form-horizontal','files'=>true]); ?>



                                            <input type="hidden" name="fund_id" value="<?php echo e($fund->id); ?>">

                                            <div class="form-group">

                                                <div class="col-sm-8 col-md-offset-2">
                                                    <div class="text-center">
                                                        <h4 class="bold" style="font-size: 24px;border-bottom: 2px dotted ;padding-bottom: 15px;text-transform: uppercase">Deposit Proof</h4>
                                                    </div>
                                                    <br>
                                                    <br>
                                                </div>
                                            </div>
                                            <br>
                                            <br>
                                            <br>

                                            <div class="row">
                                            <div class="form-group">
                                                <label style="margin-top: 5px;font-size: 14px;" class="col-sm-3 col-sm-offset-1 text-right control-label"><strong>Select Multiple Image : </strong></label>

                                                <div class="col-sm-6">
                                                    <div class="input-group">
                                                        <input type="file" value="" name="image[]" multiple class="form-control bold" required>
                                                        <span class="input-group-addon red">&nbsp;<strong> <i class="fa fa-picture-o"></i> </strong></span>
                                                    </div>
                                                </div>
                                            </div>
                                            </div>
                                            <br>
                                            <div class="row">
                                            <div class="form-group">
                                                <label style="margin-top: 5px;font-size: 14px;" class="col-sm-3 col-sm-offset-1 text-right control-label"><strong>Meessage : </strong></label>

                                                <div class="col-sm-6">
                                                    <textarea name="message" id="area1" cols="30" rows="3"
                                                              class="input-lg form-control"></textarea>
                                                </div>
                                            </div>
                                            </div>

                                            <br>
                                            <div class="row">
                                                <div class="form-group">
                                                    <div class="col-sm-6 col-sm-offset-4">
                                                        <button class="btn-primary btn-block bold btn-lg"><i class="fa fa-send"></i> Submit Now</button>
                                                    </div>
                                                </div>
                                            </div>



                                            <?php echo Form::close(); ?>

                                        </div>


                                <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div><!-- ROW-->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>