<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-12">
                    <h3 class="page_title"><?php echo $page_title; ?> </h3>
                    <hr>
                </div>
            </div>
            <div class="row">

                <?php $__currentLoopData = $plan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-sm-4 text-center">
                        <div class="panel panel-primary panel-pricing">
                            <div class="panel-heading">
                                <h3 style="font-size: 28px;"><b><?php echo e($p->name); ?></b></h3>
                            </div>
                            <div style="font-size: 18px;padding: 18px;" class="panel-body text-center">
                                <p><strong><?php echo e($p->minimum); ?> <?php echo e($basic->currency); ?> - <?php echo e($p->maximum); ?> <?php echo e($basic->currency); ?></strong></p>
                            </div>
                            <ul style='font-size: 15px;' class="list-group text-center bold">
                                <li class="list-group-item"><i class="fa fa-check"></i> Commission - <?php echo e($p->percent); ?> <i class="fa fa-percent"></i> </li>
                                <li class="list-group-item"><i class="fa fa-check"></i> Repeat - <?php echo e($p->time); ?> times </li>
                                <li class="list-group-item"><i class="fa fa-check"></i> Compound - <span class="aaaa"><?php echo e($p->compound->name); ?></span></li>
                            </ul>
                            <div class="panel-footer" style="overflow: hidden">
                                <div class="col-sm-12">
                                    <form method="POST" action="<?php echo e(route('investment-post')); ?>" class="form-inline">
                                        <?php echo e(csrf_field()); ?>

                                        <input type="hidden" name="id" value="<?php echo e($p->id); ?>">
                                        <button type="submit" class="btn btn-primary bold uppercase btn-block btn-icon icon-left">
                                            <i class="fa fa-send"></i> Invest Under This Package
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div><!---ROW-->


    
        
            
                
                    
                    
                

                
                    
                

                
                    
                        
                        

                        
                        
                    
                

            
        
    


<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

    
        

            
                
                
            
        
    

    <?php if(session('success')): ?>
        <script type="text/javascript">
            $(document).ready(function(){

                swal("Success!", "<?php echo e(session('success')); ?>", "success");

            });
        </script>

    <?php endif; ?>



    <?php if(session('alert')): ?>

        <script type="text/javascript">
            $(document).ready(function(){
                swal("Sorry!", "<?php echo e(session('alert')); ?>", "error");
            });

        </script>

    <?php endif; ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.user-frontend.user-dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>